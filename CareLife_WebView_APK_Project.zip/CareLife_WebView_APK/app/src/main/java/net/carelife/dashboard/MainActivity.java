package net.carelife.dashboard;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.graphics.Typeface;
import android.content.Context;
import android.os.Build;
import android.provider.OpenableColumns;
import android.database.Cursor;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import android.util.Base64;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://yttrium.serv00.net/test/";
    private static final String HOME_HOST = "yttrium.serv00.net";
    private WebView webView;
    private ProgressBar progress;
    private FrameLayout splash;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 7001;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(15, 23, 42));
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();
        setupWebView();
        if (state != null) {
            if (webView.restoreState(state) == null) webView.loadUrl(HOME_URL);
        } else {
            webView.loadUrl(HOME_URL);
        }
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        FrameLayout.LayoutParams bar = new FrameLayout.LayoutParams(-1, 5, Gravity.TOP);
        root.addView(progress, bar);

        splash = new FrameLayout(this);
        splash.setBackgroundColor(Color.rgb(15, 23, 42));
        LinearLayout center = new LinearLayout(this);
        center.setGravity(Gravity.CENTER);
        center.setOrientation(LinearLayout.VERTICAL);
        TextView logo = new TextView(this);
        logo.setText("CL");
        logo.setTextColor(Color.WHITE);
        logo.setTextSize(34);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        logo.setGravity(Gravity.CENTER);
        logo.setBackgroundColor(Color.rgb(37, 99, 235));
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(92, 92);
        center.addView(logo, logoLp);

        TextView title = new TextView(this);
        title.setText("CARE LIFE");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 18, 0, 4);
        center.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Business Dashboard");
        sub.setTextColor(Color.LTGRAY);
        sub.setTextSize(14);
        center.addView(sub);

        ProgressBar spinner = new ProgressBar(this);
        LinearLayout.LayoutParams spinLp = new LinearLayout.LayoutParams(48, 48);
        spinLp.topMargin = 28;
        center.addView(spinner, spinLp);

        splash.addView(center, new FrameLayout.LayoutParams(-1, -1));
        root.addView(splash);
        setContentView(root);
    }

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 21) cm.setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new WebBridge(), "CareLife");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return routeUrl(req.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeUrl(Uri.parse(url));
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                progress.setVisibility(View.VISIBLE);
            }
            @Override public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                splash.setVisibility(View.GONE);
                injectPrintBridge();
                CookieManager.getInstance().flush();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "ফাইল নির্বাচন করা যাচ্ছে না", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String ua, String disposition,
                    String mime, long length) {
                downloadUrl(url, ua, disposition, mime);
            }
        });
    }

    private boolean routeUrl(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme();
        String host = uri.getHost();
        if (("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme))
                && host != null && (host.equals(HOME_HOST) || host.endsWith("." + HOME_HOST))) {
            return false;
        }
        if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)
                || "mailto".equalsIgnoreCase(scheme) || "tel".equalsIgnoreCase(scheme)) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
            catch (Exception e) { Toast.makeText(this, "লিংক খোলা যাচ্ছে না", Toast.LENGTH_SHORT).show(); }
            return true;
        }
        return true;
    }

    private void injectPrintBridge() {
        String js = "(function(){"
          + "if(window.__careLifePrintReady)return;window.__careLifePrintReady=true;"
          + "window.print=function(){CareLife.printPage(document.title||'Care Life');};"
          + "document.addEventListener('click',function(ev){"
          + "var a=ev.target&&ev.target.closest?ev.target.closest('a[download]'):null;"
          + "if(a&&a.href&&a.href.indexOf('blob:')===0){"
          + "ev.preventDefault();var name=a.getAttribute('download')||'download';"
          + "fetch(a.href).then(function(r){return r.blob();}).then(function(b){"
          + "var fr=new FileReader();fr.onloadend=function(){"
          + "var data=String(fr.result).split(',')[1]||'';"
          + "CareLife.saveBlob(data,name,b.type||'application/octet-stream');};fr.readAsDataURL(b);"
          + "}).catch(function(){alert('ফাইল ডাউনলোড করা যায়নি');});"
          + "}},true);"
          + "})();";
        if (Build.VERSION.SDK_INT >= 19) webView.evaluateJavascript(js, null);
        else webView.loadUrl("javascript:" + js);
    }

    private void startPrint(String jobName) {
        if (Build.VERSION.SDK_INT < 19) {
            Toast.makeText(this, "এই Android সংস্করণে Print সমর্থিত নয়", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(
                    jobName == null || jobName.trim().isEmpty() ? "Care Life" : jobName);
            pm.print(jobName == null ? "Care Life" : jobName, adapter,
                    new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new android.print.PrintAttributes.Resolution("carelife", "Default", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
        } catch (Exception e) {
            Toast.makeText(this, "Print চালু করা যায়নি", Toast.LENGTH_LONG).show();
        }
    }

    private void downloadUrl(String url, String ua, String disposition, String mime) {
        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            String name = URLUtil.guessFileName(url, disposition, mime);
            request.setTitle(name);
            request.setDescription("Care Life Dashboard");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            if (mime != null) request.setMimeType(mime);
            if (ua != null) request.addRequestHeader("User-Agent", ua);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) request.addRequestHeader("Cookie", cookie);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            dm.enqueue(request);
            Toast.makeText(this, "ডাউনলোড শুরু হয়েছে", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "ডাউনলোড করা যায়নি", Toast.LENGTH_LONG).show();
        }
    }

    private class WebBridge {
        @JavascriptInterface public void printPage(final String title) {
            runOnUiThread(new Runnable() {
                @Override public void run() { startPrint(title); }
            });
        }

        // For JavaScript-created Blob files (PDF/CSV generated in the page).
        @JavascriptInterface public void saveBlob(final String base64, final String fileName, final String mime) {
            new Thread(new Runnable() {
                @Override public void run() {
                    try {
                        byte[] data = Base64.decode(base64, Base64.DEFAULT);
                        String safeName = fileName == null ? "download" : fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
                        java.io.File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                        if (!dir.exists()) dir.mkdirs();
                        java.io.File out = new java.io.File(dir, safeName);
                        java.io.FileOutputStream stream = new java.io.FileOutputStream(out);
                        stream.write(data);
                        stream.close();
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                Toast.makeText(MainActivity.this, "ফাইল Downloads ফোল্ডারে সেভ হয়েছে", Toast.LENGTH_LONG).show();
                            }
                        });
                    } catch (Exception e) {
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                Toast.makeText(MainActivity.this, "ফাইল সেভ করা যায়নি", Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                }
            }).start();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else new AlertDialog.Builder(this).setTitle("অ্যাপ বন্ধ করবেন?")
                .setMessage("Care Life Dashboard থেকে বের হতে চান?")
                .setNegativeButton("না", null)
                .setPositiveButton("হ্যাঁ", (d, w) -> finish()).show();
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (webView != null) webView.saveState(out);
    }

    @Override protected void onDestroy() {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }
}
